import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify, g

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(app.instance_path, "planner.db"))
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    with app.app_context():
        db().execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                event_date TEXT NOT NULL,
                start_time TEXT NOT NULL DEFAULT '09:00',
                end_time TEXT NOT NULL DEFAULT '10:00',
                category TEXT NOT NULL DEFAULT 'work',
                notes TEXT NOT NULL DEFAULT '',
                done INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db().commit()

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/events")
def list_events():
    start = request.args.get("start", "")
    end = request.args.get("end", "")
    rows = db().execute(
        "SELECT * FROM events WHERE event_date BETWEEN ? AND ? ORDER BY event_date, start_time",
        (start, end)
    ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/events")
def create_event():
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    event_date = data.get("event_date", "")
    start_time = data.get("start_time", "09:00")
    end_time = data.get("end_time", "10:00")
    category = data.get("category", "work")
    notes = (data.get("notes") or "").strip()
    if not title or not event_date:
        return jsonify(error="Укажите название и дату события"), 400
    try:
        datetime.strptime(event_date, "%Y-%m-%d")
        datetime.strptime(start_time, "%H:%M")
        datetime.strptime(end_time, "%H:%M")
    except ValueError:
        return jsonify(error="Некорректная дата или время"), 400
    if end_time <= start_time:
        return jsonify(error="Время окончания должно быть позже начала"), 400
    if category not in ("work", "personal", "health", "other"):
        category = "other"
    cur = db().execute(
        "INSERT INTO events(title,event_date,start_time,end_time,category,notes) VALUES(?,?,?,?,?,?)",
        (title, event_date, start_time, end_time, category, notes)
    )
    db().commit()
    row = db().execute("SELECT * FROM events WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201

@app.put("/api/events/<int:event_id>")
def update_event(event_id):
    data = request.get_json(silent=True) or {}
    existing = db().execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
    if not existing:
        return jsonify(error="Событие не найдено"), 404
    title = (data.get("title", existing["title"]) or "").strip()
    event_date = data.get("event_date", existing["event_date"])
    start_time = data.get("start_time", existing["start_time"])
    end_time = data.get("end_time", existing["end_time"])
    category = data.get("category", existing["category"])
    notes = (data.get("notes", existing["notes"]) or "").strip()
    done = int(bool(data.get("done", existing["done"])))
    if not title or end_time <= start_time:
        return jsonify(error="Проверьте название и время события"), 400
    if category not in ("work", "personal", "health", "other"):
        category = "other"
    db().execute("""UPDATE events SET title=?,event_date=?,start_time=?,end_time=?,
                    category=?,notes=?,done=? WHERE id=?""",
                 (title,event_date,start_time,end_time,category,notes,done,event_id))
    db().commit()
    return jsonify(dict(db().execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()))

@app.delete("/api/events/<int:event_id>")
def delete_event(event_id):
    db().execute("DELETE FROM events WHERE id=?", (event_id,))
    db().commit()
    return jsonify(ok=True)

@app.patch("/api/events/<int:event_id>/toggle")
def toggle_event(event_id):
    row = db().execute("SELECT done FROM events WHERE id=?", (event_id,)).fetchone()
    if not row:
        return jsonify(error="Событие не найдено"), 404
    db().execute("UPDATE events SET done=? WHERE id=?", (0 if row["done"] else 1, event_id))
    db().commit()
    return jsonify(ok=True, done=not bool(row["done"]))

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
