const $ = id => document.getElementById(id);
const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const weekdayNames = ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'];
const today = new Date(); today.setHours(0,0,0,0);
let shown = new Date(today.getFullYear(), today.getMonth(), 1);
let selected = new Date(today);
let events = [];
let editingId = null;
const iso = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const same = (a,b) => iso(a) === iso(b);
const categoryNames = {work:'Работа',personal:'Личное',health:'Здоровье',other:'Другое'};
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url, options={}) {
  const res = await fetch(url,{headers:{'Content-Type':'application/json'},...options});
  const data = await res.json();
  if(!res.ok) throw new Error(data.error || 'Не удалось выполнить запрос');
  return data;
}
function renderCalendar(){
  $('monthTitle').textContent = `${monthNames[shown.getMonth()]} ${shown.getFullYear()}`;
  const first = new Date(shown.getFullYear(),shown.getMonth(),1);
  const offset = (first.getDay()+6)%7;
  const start = new Date(first); start.setDate(first.getDate()-offset);
  const grid = $('calendarGrid'); grid.innerHTML='';
  for(let i=0;i<42;i++){
    const d=new Date(start); d.setDate(start.getDate()+i);
    if(i>=35 && d.getMonth()!==shown.getMonth()) break;
    const dayEvents=events.filter(e=>e.event_date===iso(d));
    const button=document.createElement('button');
    button.className='day'+(d.getMonth()!==shown.getMonth()?' outside':'')+(same(d,today)?' today':'')+(same(d,selected)?' selected':'');
    button.innerHTML=`<span class="num">${d.getDate()}</span><span class="dots">${[...new Set(dayEvents.map(e=>e.category))].slice(0,3).map(c=>`<i class="dot ${c}"></i>`).join('')}</span>`;
    button.addEventListener('click',()=>{selected=d; if(d.getMonth()!==shown.getMonth())shown=new Date(d.getFullYear(),d.getMonth(),1); renderAll();});
    grid.appendChild(button);
  }
}
function renderDay(){
  $('selectedDateTitle').textContent=`${selected.getDate()} ${monthNames[selected.getMonth()].toLowerCase()}, ${weekdayNames[selected.getDay()].toLowerCase()}`;
  const dayEvents=events.filter(e=>e.event_date===iso(selected)).sort((a,b)=>a.start_time.localeCompare(b.start_time));
  const done=dayEvents.filter(e=>e.done).length, pct=dayEvents.length?Math.round(done/dayEvents.length*100):0;
  $('progressText').textContent=dayEvents.length?`${done} из ${dayEvents.length} событий выполнено`:'Пока нет событий';
  $('progressPercent').textContent=pct+'%'; $('progressBar').style.width=pct+'%';
  $('emptyState').style.display=dayEvents.length?'none':'block';
  $('eventList').innerHTML=dayEvents.map(e=>`
    <article class="event-card ${e.done?'done':''}">
      <div class="event-time">${esc(e.start_time)}</div>
      <div class="event-stripe ${esc(e.category)}"></div>
      <div class="event-main" data-edit="${e.id}"><strong>${esc(e.title)}</strong><small>${esc(categoryNames[e.category]||'Другое')} · до ${esc(e.end_time)}${e.notes?' · '+esc(e.notes):''}</small></div>
      <button class="check-button ${e.done?'checked':''}" data-toggle="${e.id}" aria-label="Отметить выполненным">${e.done?'✓':'○'}</button>
    </article>`).join('');
  document.querySelectorAll('[data-edit]').forEach(el=>el.addEventListener('click',()=>openModal(Number(el.dataset.edit))));
  document.querySelectorAll('[data-toggle]').forEach(el=>el.addEventListener('click',async()=>{try{await api(`/api/events/${el.dataset.toggle}/toggle`,{method:'PATCH'});await loadEvents();}catch(e){toast(e.message)}}));
}
function renderAll(){renderCalendar();renderDay();}
async function loadEvents(){
  const start=new Date(shown.getFullYear(),shown.getMonth(),1); start.setDate(start.getDate()-7);
  const end=new Date(shown.getFullYear(),shown.getMonth()+1,7);
  events=await api(`/api/events?start=${iso(start)}&end=${iso(end)}`);
  renderAll();
}
function openModal(id=null){
  editingId=id;
  const e=id?events.find(x=>x.id===id):null;
  $('eventForm').reset(); $('formError').textContent='';
  $('modalTitle').textContent=e?'Изменить событие':'Запланировать';
  $('eventName').value=e?.title||'';
  $('eventDate').value=e?.event_date||iso(selected);
  $('eventCategory').value=e?.category||'work';
  $('startTime').value=e?.start_time||'09:00';
  $('endTime').value=e?.end_time||'10:00';
  $('eventNotes').value=e?.notes||'';
  $('deleteEventBtn').hidden=!e;
  $('eventModal').classList.add('open'); $('eventModal').setAttribute('aria-hidden','false');
  setTimeout(()=>$('eventName').focus(),100);
}
function closeModal(){$('eventModal').classList.remove('open');$('eventModal').setAttribute('aria-hidden','true');}
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2300);}
$('eventForm').addEventListener('submit',async ev=>{
  ev.preventDefault(); $('formError').textContent='';
  const payload={title:$('eventName').value.trim(),event_date:$('eventDate').value,category:$('eventCategory').value,start_time:$('startTime').value,end_time:$('endTime').value,notes:$('eventNotes').value};
  try{
    await api(editingId?`/api/events/${editingId}`:'/api/events',{method:editingId?'PUT':'POST',body:JSON.stringify(payload)});
    selected=new Date(payload.event_date+'T00:00:00');shown=new Date(selected.getFullYear(),selected.getMonth(),1);
    closeModal();await loadEvents();toast(editingId?'Событие обновлено':'Событие добавлено');
  }catch(e){$('formError').textContent=e.message;}
});
$('deleteEventBtn').addEventListener('click',async()=>{
  if(!editingId)return;
  if(!confirm('Удалить это событие?'))return;
  try{await api(`/api/events/${editingId}`,{method:'DELETE'});closeModal();await loadEvents();toast('Событие удалено');}catch(e){toast(e.message);}
});
$('addEventBtn').onclick=()=>openModal();$('emptyAddBtn').onclick=()=>openModal();$('closeModal').onclick=closeModal;
$('eventModal').addEventListener('click',e=>{if(e.target===$('eventModal'))closeModal()});
$('prevMonth').onclick=()=>{shown.setMonth(shown.getMonth()-1);loadEvents()};
$('nextMonth').onclick=()=>{shown.setMonth(shown.getMonth()+1);loadEvents()};
$('todayBtn').onclick=()=>{selected=new Date(today);shown=new Date(today.getFullYear(),today.getMonth(),1);loadEvents()};
loadEvents().catch(e=>toast(e.message));
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/static/sw.js').catch(()=>{}));
